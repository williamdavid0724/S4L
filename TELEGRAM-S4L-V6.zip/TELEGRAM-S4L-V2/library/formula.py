from library import fun_api as api
from library import mi_telegram as tl
from library import my_load_text as tx
from library import my_credentials as crd
import pandas as pd
import numpy as np
import dataframe_image as dfi
from PIL import Image
from PIL import ImageFont 
from PIL import ImageDraw 
# from cv2 import imread
from datetime import datetime
from datetime import time
from datetime import date
from datetime import timedelta
import time


def send_formula(id_chat,update):
    TOKEN,URL = crd.credentialstl()
    namepng = elaborate_formula(id_chat)
    if namepng == "Sin_datos.png":
        texto_respuesta ="No tienes fórmulas pendientes por procesar"
    else:
        tl.enviar_imagen(id_chat, namepng,TOKEN)
        texto_respuesta = '¿Ya tienes todos los medicamentos 💊 de tu fórmula disponibles? 🤔'
    update.message.reply_text(texto_respuesta,parse_mode = "Markdown")
    tx.registro(id_chat,"transaccional","0","1","0","0","0","0") 
    print('Exit 4')


def elaborate_formula(id_telegram):
    print(id_telegram)
    data= api.ObtenerPosologiaPaciente(id_telegram) 
    df = pd.DataFrame.from_dict(data.get('result'), orient='columns', dtype=None)
    lista = ['NombreMedicamento','NombreFormaFarmaceutica','NombreConcentracion','Descripcion','Frecuencia']
    if df.empty:
        namepng = "Sin_datos.png"
    else:
        dfx = df[(df['Revisado'] == '')]   
        df1 = dfx[lista]
        namepng1 = "F" + str('1477550675') + ".png" 
        namepng = str('1477550675') + ".png" 
        dfi.export(df1, namepng1)
        img = Image.open(namepng1)
        height, width  = img.size 
        alto = height + 300
        img = Image.new('RGB', (900,alto), "white")
        draw = ImageDraw.Draw(img) 
        font = ImageFont.truetype("LiberationSerif-Bold.ttf", 36) 
        font3 = ImageFont.truetype("LiberationSerif-Bold.ttf", 26) 
        font2 = ImageFont.truetype("LiberationSerif-Bold.ttf", 25) 
        # draw.text((892, 10),FECHA ,(180,0,80),font=font2) 
        draw.text((350, 50),"FÓRMULA ",(180,0,80),font=font) 
        # draw.text((10, 100),CLIENTE,(180,0,80),font=font3) 
        # draw.text((10, 130),EDI,(180,0,80),font=font3) 
        # draw.text((10, 160),ENTREGA,(180,0,80),font=font3) 
        im_logo = Image.open(namepng1)
        img.paste(im_logo,(10, 220))
        img.save(namepng)
    return namepng

#=========================================================================================================

def Envio_recordatoriosbd(X):
    api.TomaMedicamentos(X['idTelegram'],X['IdPosologia'],X['TOMA_MEDICAMENTO'],str(X['fecha']),X['PROCESADO'],X['NO_ENVIOS'],X['recordatorioTipo'])
    api.ActualizarRevisado(X['idTelegram'],X['IdPosologia'])
    return 1

def schedule_medications(X):
    ahora = datetime.now()
    fecha_toma = str(date.today()) + ' ' + X['Hora']  + ':00'
#     print(fecha_toma)
    fecha_dosis = datetime.strptime(fecha_toma, '%Y-%m-%d %H:%M:%S')
#     print(fecha_dosis)
    if X['Frecuencia'] == 'DIARIAMENTE, CADA X HORA':
        if ahora <= fecha_dosis:
            inicio = fecha_dosis
        else:
            inicio = fecha_dosis + timedelta(days=1) 
        frecuencia = str(X['MAPEO_FRECUENCIA']) + 'H' 
        print(frecuencia)
        dserie2 = pd.date_range(inicio, periods = 30, freq=frecuencia)   
    elif X['Frecuencia'] == 'DÍAS ESPECÍFICOS DE LA SEMANA':
        DIAS_SEM = {'LUNES':1, 'MARTES':2, 'MIERCOLES':3,'JUEVES':4, 'VIERNES':5, 'SABADO':6, 'DOMINGO':0}
        ldias = []
        print(X['Descripcion'],'XDescripcion')
        if type(X['Descripcion']) is list:
            print('es lista')            
            for dia in X['Descripcion']:
                print(dia)
                ldias.append(DIAS_SEM[dia])
#             print(ldias) 
            if dia in ldias:
                semana = datetime.today().isocalendar().week
                print(semana,'semana')
                year = datetime.now().strftime('%Y')
                d = str(year) + ' ' + str(semana) + ' ' + str(dia) + ' ' + X['Hora']  + ':00'
                fecha = time.asctime(time.strptime(d,'%Y %W %w %H:%M:%S')) # 
                date1 = pd.to_datetime(fecha)               
                if ahora <= date1:
                    inicio = hora_dosis
                else:
                    inicio = date1 + timedelta(days=7)                         
                    print(inicio,'programa recordatorio6')
        else:
            dia = DIAS_SEM[X['Descripcion']]
            print('else')            
            semana = datetime.today().isocalendar().week
#             print(semana,'semana')
            year = datetime.now().strftime('%Y')
            d = str(year) + ' ' + str(semana) + ' ' + str(dia) + ' ' + X['Hora']  + ':00'
#             print(d)
            fecha = time.asctime(time.strptime(d,'%Y %W %w %H:%M:%S')) # 
            date1 = pd.to_datetime(fecha)               
            if ahora <= date1:
                inicio = date1
            else:
                inicio = date1 + timedelta(days=7)                         
                print(inicio,'programa recordatorio6')
        dserie2 = pd.date_range(inicio, periods = 4, freq='W')  
    elif X['Frecuencia'] == 'CADA X DÍAS':
        if ahora <= fecha_dosis:
            inicio = fecha_dosis
        else:
            inicio = fecha_dosis + timedelta(days=1) 
        frecuencia = str(X['Descripcion']) + 'D' 
        print(frecuencia)
        dserie2 = pd.date_range(inicio, periods = 30, freq=frecuencia)    
    lIdPosologia = []
    lIdMedicamento = []
    lIdFormaFarmaceutica =[]
    lNombreConcentracion =[]
    lNombreMedicamento = []
    lidTelegram = []
    lNombreFormaFarmaceutica =[]  
    for serie in dserie2:
        lIdPosologia.append(X['IdPosologia'])
        lIdMedicamento.append(X['IdMedicamento'])
        lIdFormaFarmaceutica.append(X['IdFormaFarmaceutica'])
        lNombreConcentracion.append(X['NombreConcentracion'])
        lNombreMedicamento.append(X['NombreMedicamento'])
        lidTelegram.append(X['idTelegram'])
        lNombreFormaFarmaceutica.append(X['NombreFormaFarmaceutica'])   
    programa_recordatorios = pd.DataFrame()
    programa_recordatorios['fecha'] = dserie2
    programa_recordatorios['IdPosologia'] = lIdPosologia 
    programa_recordatorios['IdMedicamento'] = lIdMedicamento 
    programa_recordatorios['IdFormaFarmaceutica'] = lIdFormaFarmaceutica 
    programa_recordatorios['NombreConcentracion'] = lNombreConcentracion
    programa_recordatorios['NombreMedicamento'] = lNombreMedicamento 
    programa_recordatorios['idTelegram'] = lidTelegram 
    programa_recordatorios['NombreFormaFarmaceutica'] = lNombreFormaFarmaceutica
    programa_recordatorios['PROCESADO'] = 'NO'
    programa_recordatorios['TOMA_MEDICAMENTO'] = ''
    programa_recordatorios['NO_ENVIOS'] = 0
    programa_recordatorios['recordatorioTipo'] = 1
    programa_recordatorios['servicio'] = programa_recordatorios.apply(lambda x : Envio_recordatoriosbd(x), axis=1)     
    return 1   

                
def elaborate_formula2(id_telegram):
    data = api.ObtenerPosologiaPaciente(id_telegram) # no tengo datos
    df = pd.DataFrame.from_dict(data.get('result'), orient='columns', dtype=None)
    mp_frecuencias= pd.read_csv('MAPEO_FRECUENCIAS.txt', sep=';',encoding='latin-1', error_bad_lines=False)    
    data = df.merge(mp_frecuencias)
    data1 = data[(data['Revisado'] == '')]     
    data1['procesado'] = data1.apply(lambda x : schedule_medications(x), axis=1)     
    return data