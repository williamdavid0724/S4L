
import os

def registro(idchat,nivel,cc,cons,aux5="0",aux6="0",aux7="0",aux8="0",aux9="0"):
    nombre = str(idchat) + ".txt"
    file = open(nombre,'w',encoding = 'utf-8') 
    file.write(nivel + "\n")
    file.write(str(cc) + "\n")
    file.write(str(cons)+ "\n")
    file.write(str(aux5)+ "\n")
    file.write(str(aux6)+ "\n")
    file.write(str(aux7)+ "\n")
    file.write(str(aux8)+ "\n")
    file.write(str(aux9))
    file.close()

def collect_data(usuario1,idchat):
    lista_archivos = os.listdir() #GENERA LISTA DE ARCHIVOS UBICADOS EN EL DIRECTORIO.
    if usuario1 in lista_archivos:
        archivo1 = open(usuario1, "r", encoding="utf8") #APERTURA DE ARCHIVO EN MODO LECTURA
        verifica = archivo1.read().splitlines() #LECTURA DEL ARCHIVO QUE CONTIENE EL nombre Y contraseña.
    else:
        registro(idchat,"0","0","0","0","0","0","0","0")
        verifica = ["0","0","0","0","0","0","0","0"]            
    return verifica

def collect_data_pedido(url):
    lpedidos = open(url, "r").read().split(',') #APERTURA DE ARCHIVO EN MODO LECTURA
    return lpedidos

def guardarlispedidos(idchat,lista):
    nombre = "LP" + str(idchat) + ".txt"
    file = open(nombre,'w',encoding = 'utf-8') 
    listaf  = ','.join(str(e) for e in lista)
    file.write(listaf)
    file.close()