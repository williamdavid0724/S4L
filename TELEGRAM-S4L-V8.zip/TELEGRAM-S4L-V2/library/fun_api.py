# encoding: utf-8

from flask import Flask, jsonify, request, json
import urllib3
import certifi
import json
import numpy as np
import pandas as pd 


http = urllib3.PoolManager(ca_certs=certifi.where())

def saveidtelegram(numeroDocumento,idTelegram):
    '''se guardará el id de Telegram el cual se asociará al usuario'''
    payload = {
    "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "tipoDocumento": "CC", 
        "numeroDocumento": numeroDocumento,
        "idTelegram": idTelegram
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/IdTelegram',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    result = data.get('result').get('message')
    return data

def ObtenerConsolidadoPosologia():
    '''El Primer servicio se encontrará un arreglo con todos los pacientes que entran en el programa de envió 
    de mensajes por Telegrama con la información de personal referente a número cedula, celular y nombres entre otros.''' 
        
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32"
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/ObtenerConsolidadoPosologia',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))    
    df = pd.DataFrame.from_dict(data.get('result'), orient='columns', dtype=None)
    return df

def ConsultaTomaMedicamentos(idTelegram):
    '''El Primer servicio se encontrará un arreglo con todos los pacientes que entran en el programa de envió 
    de mensajes por Telegrama con la información de personal referente a número cedula, celular y nombres entre otros.''' 
        
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram,
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/ConsultaTomaMedicamentos',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))    
    df = pd.DataFrame.from_dict(data.get('result'), orient='columns', dtype=None)
    return df

def TerminosPaciente(numeroDocumento,rta):
    '''se envía el resultado de los términos de aceptación de la aplicación si contestas no se guarda este y termina el proceso si contesta si se pasa al siguiente servicio'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "tipoDocumento": "CC", 
        "numeroDocumento": numeroDocumento,
        "resultadoTerminos": rta
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/TerminosPaciente',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    result = data.get('result').get('message')
    return result





def CuentaMedicamentos(idTelegram,fechaInicioMedicamentos):
    '''para guardar la información en caso de que el paciente cuente con todos los medicamentos, almacenando la respuesta si y la fecha de inicio de toma de medicamentos.'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram,
        "fechaInicioMedicamentos ": fechaInicioMedicamentos #"2021-12-02"
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/CuentaMedicamentos',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    result = data.get('result').get('message')
    return result


def NoCuentaMedicamentos(idTelegram,porQue,fechaPorQue):
    '''se utiliza para saber por qué no tiene los medicamentos y guardar la fecha en la que se tiene que preguntar nuevamente teniendo en cuenta que las opciones (No tengo formula actualizada, No hay existencias en farmacia, No los ha reclamado).'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram,
        "porQue": porQue,
        "fechaPorQue": fechaPorQue
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/NoCuentaMedicamentos',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    result = data.get('result').get('message')
    return result

def ActualizarRevisado(idTelegram,IdPosologia):
    '''se utiliza para saber por qué no tiene los medicamentos y guardar la fecha en la que se tiene que preguntar nuevamente teniendo en cuenta que las opciones (No tengo formula actualizada, No hay existencias en farmacia, No los ha reclamado).'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram,
        "idPosologia": IdPosologia,
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/ActualizarRevisado',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})



def TomaMedicamentos(idTelegram,idPosologia,resultadoToma,fechaHoraToma,procesado,numeroEnvio,recordatorioTipo):
    '''se utiliza para almacenar la respuesta de toma de cada uno de los medicamentos al día, asociados el tiempo de toma del medicamento si lo hace en el horario establecido.'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram,
        "idPosologia": idPosologia,
        "resultadoToma": resultadoToma,#---- No se tiene registro de ingesta de medicamento
        "fechaHoraToma": fechaHoraToma,#----- null
        "procesado": procesado,
        "numeroEnvio": numeroEnvio,
        "recordatorioTipo": recordatorioTipo

    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/TomaMedicamentos',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    return data

def EfectividadPaciente():
    '''está asociado a la efectividad de la toma de los medicamentos por paciente, en el cual se generará una respuesta de Si o No dependiendo de si la efectividad es >95% para seleccionar que mensaje se le envía al paciente.'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": "1234567",
        "idPosologia ": "123",
        "fechaEvaluar": "2021-12-20"

    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/EfectividadPaciente',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    return data

def ConsultaCuentaMedicamentos(idTelegram):
    '''Está asociado a la consulta de los parámetros de si un paciente cuenta o no con medicamentos.'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/ConsultaCuentaMedicamentos',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    return data

def EliminarIdTelegram(idTelegram):
    '''asociado a la eliminar los parámetros asociados a un id de Telegram referente referentes a la Fase 2 y 3 del diagrame de flujo.'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram":idTelegram
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/EliminarIdTelegram',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    result = data.get('result').get('message')
    return result




def Validate_existence_id_pac(id_pac):
    try:
        valor = int(id_pac)
        datos = ObtenerConsolidadoPosologia()
        paciente =  datos.query('id_pac == ' +  str(id_pac))
        if paciente.empty:
            exist_patient = False
            Nombre_OK = ''
        else:
            nombre = paciente['pac_pnombre']
            Nombre_OK = ''.join(str(x) for x in nombre)
            exist_patient = True
        return exist_patient,Nombre_OK  
    except ValueError:
        exist_patient = False
        Nombre_OK  = ""        
        return exist_patient,Nombre_OK      
    
    
#==========================================Check================================================================================    
    
    
def Validate_existence_id_telegram(id_telegram):
    '''se utiliza para verificar si el id_telegram existe en Mafe.'''    
    datos = ObtenerConsolidadoPosologia()
    paciente =  datos.query('id_telegram == ' +  str(id_telegram))
    if paciente.empty:
        exist_patient = False
    else:
        exist_patient = True
    return exist_patient    



def ObtenerPosologiaPaciente(idTelegram):
    '''se encontrará la información de los medicamentos y su indicación de toma asociada a un paciente'''    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idTelegram": idTelegram
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/ObtenerPosologiaPaciente',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    return data



def ActualizarTomaMedicamentos(idAlerta,resultadoToma,procesado,numeroEnvio):
    '''se envía el resultado de los términos de aceptación de la aplicación si contestas no se guarda este y termina el proceso si contesta si se pasa al siguiente servicio'''
    
    payload = {
        "usuario": "s4l",
        "password": "2021.S4lcu47r0L34CtXdN32",
        "idAlerta": idAlerta,
        "resultadoToma": resultadoToma,
        "procesado": procesado,
        "numeroEnvio": numeroEnvio
    }
    encoded_data = json.dumps(payload).encode('utf-8')
    resp = http.request(
         'POST',
         'https://siesservices.s4l.life/Mafe/ActualizarTomaMedicamentos',
         body=encoded_data,
         headers={'Content-Type': 'application/json'})

    data = json.loads(resp.data.decode('utf-8'))
    result = data.get('result').get('message')
    return result