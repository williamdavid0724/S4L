import my_credentials as crd
import my_load_text as tx
import fun_api as api




def key_request(NOMBRE,idchat,texto,level, sublevel, consec,aux5,aux6,aux7,aux8,aux9):
    texto_respuesta = "Buen día " + str(NOMBRE) + ", Por favor digita tu contraseña" 
    tx.registro(idchat,"LOGIN","transactional_zone_entry","0","0","0","0",aux8,aux9)
    return texto_respuesta


def collaborator_exists(nametxt,idchat,texto,level, sublevel, consec,aux5,aux6,aux7,aux8,aux9):
    if str(aux8) == "1":
        sentencia = "SELECT [COLABORADOR] FROM [REPORTESBD].[dbo].[T_COLABORADOR] where ID_COLABORADOR='" + str(consec) + "'"
    elif str(aux8) == "2":
        sentencia = "SELECT [SUPERVISOR] FROM [REPORTESBD].[dbo].[T_SUPERVISOR] where ID_SUPERVISOR='" + str(consec) + "'"
    elif str(aux8) == "3":
        sentencia = "SELECT  DIR_REGIONAL FROM [REPORTESBD].[dbo].[T_DIR_REGIONAL] where ID_DIR_REGIONAL='" + str(consec) + "'"                 
    nombre_colaborador = mysql.AWSSQL(sentencia)
    print(nombre_colaborador)
    if nombre_colaborador is None: 
        tx.registro(idchat,"0","0","0","0","0","0","0")
        texto_respuesta = "No te encuentras como colaborador asignado, solicita la creación en el gestor de Áreas comerciales,Ingrese 0 para Reiniciar."            
    else:
        nombre_colabo = ''.join(nombre_colaborador)
        texto_respuesta = register_password(nametxt,idchat,texto,level, sublevel, consec,aux5,aux6,aux7,aux8,aux9,nombre_colabo.title())
    return texto_respuesta  
        
    

       
def register_password(nametxt,idchat,texto,level, sublevel, consec,aux5,aux6,aux7,aux8,aux9,nombre_colaborador):
    if str(aux8) == "1":
        sentencia =  "UPDATE [REPORTESBD].[dbo].[T_COLABORADOR]  SET ID_CHAT='" + str(idchat) + "',PASSWORD='" + str(aux5) + "' WHERE ID_COLABORADOR='" + str(consec) + "'"
    elif str(aux8) == "2":
        sentencia =  "UPDATE [REPORTESBD].[dbo].[T_SUPERVISOR]  SET ID_CHAT='" + str(idchat) + "',PASWORD='" + str(aux5) + "' WHERE ID_SUPERVISOR='" + str(consec) + "'"
    elif str(aux8) == "3":
        sentencia =  "UPDATE [REPORTESBD].[dbo].[T_DIR_REGIONAL]  SET ID_CHAT='" + str(idchat) + "',PASWORD='" + str(aux5) + "' WHERE ID_DIR_REGIONAL='" + str(consec) + "'"
    mysql.sqlexecute(sentencia) 
    sentencia = "SET NOCOUNT ON;EXEC [dbo].[CONTROL_DATOS_TELEGRAM] '" + str(idchat) + "','" + str(nombre_colaborador) + "','" + str(aux8) + "','" + str(aux5) + "'"
    mysql.sqlexecute(sentencia) 
    print(sentencia)
    tx.registro(idchat,"LOGIN","transactional_zone_entry",consec,aux5,"auto_check_password","0",aux8,aux9)
    level, sublevel, consec,aux5,aux6,aux7,aux8,aux9 = tx.collect_data(nametxt,idchat) 
    texto_respuesta = check_password(idchat,texto,level,sublevel,consec,aux5,aux6,aux7,aux8,aux9)
    return texto_respuesta 



def check_password(idchat,texto,level,sublevel,consec,aux5,aux6,aux7,aux8,aux9):
    print('argumentos_check_password:','idchat:',idchat,'texto:',texto,'level:',level,'sublevel:', sublevel,'consec:',consec,'aux5:',aux5,'aux6:',aux6,'aux7:',aux7,'aux8:',aux8,'aux9',aux9)
    sentencia = "0"
    if aux6 != "auto_check_password":
        texto_respuesta = "Comprobando Credenciales........."
        if str(aux8) == "1":
            sentencia = "SELECT [COLABORADOR] FROM [REPORTESBD].[dbo].[T_COLABORADOR] where PASSWORD='" + str(texto) + "' AND ID_CHAT='" + str(idchat) + "'"
        elif str(aux8) == "2":
            sentencia = "SELECT SUPERVISOR FROM [REPORTESBD].[dbo].[T_SUPERVISOR] where PASWORD='" + str(texto) + "' AND ID_CHAT='" + str(idchat) + "'"
        elif str(aux8) == "3":
            sentencia = "SELECT DIR_REGIONAL FROM [REPORTESBD].[dbo].[T_DIR_REGIONAL] where PASWORD='" + str(texto) + "' AND ID_CHAT='" + str(idchat) + "'"
    elif aux6 == "auto_check_password":
        if str(aux8) == "1":
            sentencia = "SELECT [COLABORADOR] FROM [REPORTESBD].[dbo].[T_COLABORADOR] where PASSWORD='" + str(aux5) + "' AND ID_CHAT='" + str(idchat) + "'" 
        elif str(aux8) == "2":
            sentencia = "SELECT SUPERVISOR FROM [REPORTESBD].[dbo].[T_SUPERVISOR] where PASWORD='" + str(aux5) + "' AND ID_CHAT='" + str(idchat) + "'"
        elif str(aux8) == "3":
            sentencia = "SELECT DIR_REGIONAL FROM [REPORTESBD].[dbo].[T_DIR_REGIONAL] where PASWORD='" + str(aux5) + "' AND ID_CHAT='" + str(idchat) + "'"
    if sentencia == "0":
        texto_respuesta ="Error 304"
    else:    
        nombre_colaborador = mysql.AWSSQL(sentencia)
        print(nombre_colaborador)
        if nombre_colaborador is None:
                tx.registro(idchat,"0","0","0","0","0","0","0")
                texto_respuesta = "No te encuentras registrado o la contraseña es invalida, comunícate con tu supervisor"            
        else: 
            nombre_colabo = ''.join(nombre_colaborador).title()
            texto_respuesta = """%s bienvenido al Menú transaccional

    Ingrese 3 para gestionar pedidos.
    Ingrese 4 para Informes de gestión.
"""%(nombre_colabo)               

    tx.registro(idchat,"transaccional","0","0","0","0","0",aux8)   
    return texto_respuesta
