# encoding: utf-8

import telegram
import requests
import json
import pandas as pd
from datetime import datetime
from datetime import time
from datetime import date
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update,ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler #, CallbackQueryHandler, CallbackContext
from telegram import ForceReply 
from library import my_credentials as crd
from library import my_load_text as tx
from library import fun_api as api
from telegram.replykeyboardmarkup import ReplyKeyboardMarkup

# ========================================


# from telegram.ext.updater import Updater
# from telegram.ext.commandhandler import CommandHandler
from telegram.ext.callbackqueryhandler import CallbackQueryHandler
from telegram.callbackquery import CallbackQuery
from telegram.ext.callbackcontext import CallbackContext
from telegram.update import Update
from telegram.message import Message
import sys

from telegram.ext.updater import Updater
from telegram.update import Update
from telegram.ext.callbackcontext import CallbackContext
from telegram.ext.commandhandler import CommandHandler
from telegram.replykeyboardmarkup import ReplyKeyboardMarkup
from telegram.replykeyboardremove import ReplyKeyboardRemove
from telegram.ext.messagehandler import MessageHandler
# from telegram.ext.filters import Filters
import telegram



# def update(offset,URL):
#     #Llamar al metodo getUpdates del bot, utilizando un offset
#     respuesta = requests.get(URL + "getUpdates" + "?offset=" + str(offset) + "&timeout=" + str(200))
#     #Decodificar la respuesta recibida a formato UTF8
#     mensajes_js = respuesta.content.decode("utf8") 
#     #Convertir el string de JSON a un diccionario de Python
#     mensajes_diccionario = json.loads(mensajes_js) 
#     #Devolver este diccionario
#     return mensajes_diccionario



def enviar_mensaje(idchat, texto,URL):
    #Llamar el metodo sendMessage del bot, passando el texto y la id del chat
    requests.get(URL + "sendMessage?text=" + str(texto) + "&chat_id=" + str(idchat))

def send_msg(id_chat,texto,TOKEN):   
    bot = telegram.Bot(token=TOKEN)
    bot.sendMessage(chat_id = id_chat ,text =texto,parse_mode = "Markdown") 
    
def send_msg_2(id_chat,texto,TOKEN):   
    bot = telegram.Bot(token=TOKEN)
    reply_markup = ReplyKeyboardRemove()
    bot.sendMessage(chat_id = id_chat ,text =texto,parse_mode = "Markdown",reply_markup=reply_markup)     
    
    

def send_botton_keyboard(id_chat,texto_respuesta,TOKEN):   
    bot = telegram.Bot(token=TOKEN)
    kbd_layout = [['Toma realizada!']]
    kbd = ReplyKeyboardMarkup(kbd_layout)
    bot.sendMessage(chat_id = str(id_chat),text =texto_respuesta,parse_mode = "Markdown",reply_markup=kbd)    
 
    
def enviar_imagen(idchat, namepng,TOKEN):
    bot = telegram.Bot(token=TOKEN)
    with open(namepng,'rb') as photo_file:
        bot.sendPhoto(chat_id=idchat,photo=photo_file)        
  

  

# def echo(update, context):
#     """Echo the user message."""
#     print('Obtener_mensaje',update)
#     print('Obtener_Id',update.message.chat.id)
#     print('Obtener_username',update.message.chat.username)
#     print('Obtener_update_id',update.update_id)
#     print('Obtener_text',update.message.text)
#     print('Obtener_message_id',update.message.message_id)
#     update.message.reply_text(update.message.text)

# def sumar(update,context):
#     try:
#         numero1 = int(context.args[0])
#         numero2 = int(context.args[1])

#         suma = numero1 + numero2

#         update.message.reply_text("La suma es "+str(suma))

#     except (ValueError):
#         update.message.reply_text("por favor utilice dos numeros")
        
#=========================================================================================================        
#=================================================check===================================================
#=========================================================================================================

def enviar_pdf(idchat, file,TOKEN):
    bot = telegram.Bot(token=TOKEN)
    bot.sendDocument(chat_id=idchat, document=open(file, 'rb'))
    
def button_send(update: Update, context: CallbackContext):
    text = "¿Aceptas los términos y condiciones del uso de esta herramienta?"
    keyboard = [[
        InlineKeyboardButton("Sí, estoy de acuerdo", callback_data='Sí, estoy de acuerdo'),
        InlineKeyboardButton("No acepto", callback_data='No acepto')
    ]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text( text, reply_markup=reply_markup)
    pass



def button_end(update, context):
    TOKEN,URL = crd.credentialstl()
    id_chat = update.callback_query.message.chat.id
    mensaje_id = update.callback_query.message.message_id
    username = update.callback_query.message.chat.username
    query: CallbackQuery = update.callback_query
    df = pd.DataFrame()
    username_list = []
    id_chat_list = []
    fecha_list = []
    username_list.append(username)
    id_chat_list.append(id_chat)
    fecha_list.append(date.today())
    df['username'] = username_list
    df['id'] = id_chat_list
    df['fecha'] = fecha_list
    query.answer()
    bot = telegram.Bot(token=TOKEN)
    bot.sendMessage(chat_id = id_chat ,text =query.data,reply_to_message_id= mensaje_id-1)    
    if query.data == 'Sí, estoy de acuerdo':
        Text_saludo = """¿Podrías por favor digitar tu número de documento sin puntos ni comas? Con el fin de validar tu identidad. """
        enviar_mensaje(id_chat,Text_saludo,URL)         
        tx.registro(id_chat,"REGISTRO","0","0","0","0","0","0") 
        print('Exit:2')
    elif query.data== 'No acepto':
        texto_respuesta = 'Cuánto lo siento 😔 espero nos podamos encontrar en otra oportunidad, que tengas buen día.'
        enviar_mensaje(id_chat,texto_respuesta,URL) 
        tx.registro(id_chat,"EXCLUIR_POR_TERMINOS","0","0","0","0","0","0") 
        df.to_csv('No_aceptaron_terminos.txt',index=None, sep=';', mode='a') #, header=None
        print('Exit:3')
        