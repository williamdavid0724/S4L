# encoding: utf-8

def credentialstl():
    TOKEN = "1589549774:AAEM7XdwI21n55XgpkUB5lwUfExgj27MIGY" #Cambialo por tu token
    URL = "https://api.telegram.org/bot" + TOKEN + "/"
    return TOKEN,URL